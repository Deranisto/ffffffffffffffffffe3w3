// APEX MAX API VISIBILITY TESTER — backend (node:http, без фреймворков).
// Маршруты:
//   GET  /                      — панель (public/index.html)
//   GET  /api/health            — открыт: живо ли, активен ли мониторинг (без секретов)
//   POST /api/check             — диагностика каналов (нужен DIAG_KEY)
//   POST /api/monitor/start     — запуск наблюдения (нужен DIAG_KEY)
//   POST /api/monitor/stop      — остановка (нужен DIAG_KEY)
//   GET  /api/monitor/state    — состояние, события, посты (нужен DIAG_KEY)
// Токен MAX-бота живёт только здесь, в памяти сервера. В ответы он не попадает:
// runChecks отдаёт лишь user_id/username/first_name, тексты ошибок токен не содержат.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { MaxClient } from "./max.js";
import { runChecks } from "./checks.js";
import { Monitor } from "./monitor.js";

export interface ServerDeps {
  client: MaxClient;
  monitor: Monitor;
  diagKey: string;
  version: string;
}

const here = path.dirname(fileURLToPath(import.meta.url));
// dist/ лежит рядом с public/ только если public скопирован в корень образа;
// ищем public сначала рядом с dist, затем в корне проекта.
function publicDir(): string {
  const candidates = [
    path.resolve(here, "..", "public"),
    path.resolve(here, "..", "..", "public"),
    path.resolve(process.cwd(), "public"),
  ];
  for (const c of candidates) {
    if (fs.existsSync(path.join(c, "index.html"))) return c;
  }
  return candidates[0];
}

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
};

function readJson(req: http.IncomingMessage, limit = 65536): Promise<any> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let size = 0;
    req.on("data", (c: Buffer) => {
      size += c.length;
      if (size > limit) {
        reject(new Error("body too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      try {
        resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : null);
      } catch {
        reject(new Error("invalid JSON"));
      }
    });
    req.on("error", reject);
  });
}

function send(res: http.ServerResponse, code: number, obj: unknown): void {
  const b = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(b) });
  res.end(b);
}

function validChannelId(v: unknown): v is string {
  if (typeof v !== "string") return false;
  const t = v.trim();
  return /^-?\d{1,20}$/.test(t);
}

/** Проверка ключа доступа (вынесена для тестов; сравнение без утечек по времени не требуется — ключ высокоэнтропийный). */
export function checkDiagKey(req: http.IncomingMessage, diagKey: string): boolean {
  const key = req.headers["x-diag-key"];
  return typeof key === "string" && key.length > 0 && key === diagKey;
}

export function createServer(deps: ServerDeps): http.Server {
  const pub = publicDir();
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? "/", "http://localhost");
      const p = url.pathname;

      if (req.method === "GET" && (p === "/" || p === "/index.html" || p === "/app.js" || p === "/styles.css")) {
        const file = p === "/" ? "index.html" : p.slice(1);
        if (file.includes("..")) {
          res.writeHead(400).end("bad request");
          return;
        }
        const full = path.join(pub, file);
        if (!fs.existsSync(full)) {
          res.writeHead(404).end("not found");
          return;
        }
        const ext = path.extname(full);
        res.writeHead(200, { "Content-Type": MIME[ext] ?? "application/octet-stream" });
        fs.createReadStream(full).pipe(res);
        return;
      }

      if (req.method === "GET" && p === "/api/health") {
        send(res, 200, {
          ok: true,
          version: deps.version,
          now: Date.now(),
          monitorActive: deps.monitor.state.active,
          monitorSince: deps.monitor.state.since,
        });
        return;
      }

      // Дальше — только с ключом доступа. Ключ в URL/логах не фигурирует.
      if (!checkDiagKey(req, deps.diagKey)) {
        send(res, 403, { ok: false, error: "forbidden: bad or missing x-diag-key" });
        return;
      }

      if (req.method === "POST" && p === "/api/check") {
        const body = await readJson(req);
        const ids = Array.isArray(body?.channels) ? body.channels : [];
        const clean = [...new Set(ids.filter(validChannelId).map((s: string) => s.trim()))].slice(0, 2);
        if (!clean.length) {
          send(res, 400, { ok: false, error: "channels: нужно 1–2 ID каналов (числа)" });
          return;
        }
        const result = await runChecks(deps.client, clean);
        send(res, 200, { ok: true, ...result });
        return;
      }

      if (req.method === "POST" && p === "/api/monitor/start") {
        const body = await readJson(req);
        const ids = Array.isArray(body?.channels) ? body.channels : [];
        const clean = [...new Set(ids.filter(validChannelId).map((s: string) => s.trim()))].slice(0, 2);
        if (!clean.length) {
          send(res, 400, { ok: false, error: "channels: нужно 1–2 ID каналов (числа)" });
          return;
        }
        const hint = typeof body?.hint === "string" ? body.hint.slice(0, 200) : "";
        deps.monitor.start(clean, hint);
        send(res, 200, {
          ok: true,
          active: true,
          channels: clean,
          since: deps.monitor.state.since,
          note: "Наблюдение запущено. События до этого момента API не вернёт — мониторинг видит только новое.",
        });
        return;
      }

      if (req.method === "POST" && p === "/api/monitor/stop") {
        deps.monitor.stop();
        send(res, 200, { ok: true, active: false });
        return;
      }

      if (req.method === "GET" && p === "/api/monitor/state") {
        const st = deps.monitor.state;
        send(res, 200, {
          ok: true,
          active: st.active,
          channels: st.channels,
          since: st.since,
          marker: st.marker,
          events: st.events.slice(-100),
          messages: st.messages,
          log: st.log.slice(-100),
        });
        return;
      }

      send(res, 404, { ok: false, error: "not found" });
    } catch (e) {
      send(res, 500, { ok: false, error: e instanceof Error ? e.message : String(e) });
    }
  });
  return server;
}
