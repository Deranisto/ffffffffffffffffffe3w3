// APEX MAX API VISIBILITY TESTER — клиент официального MAX Bot API.
// База: https://platform-api2.max.ru (platform-api.max.ru устарел).
// Авторизация: заголовок `Authorization: <access_token>`.
// Используются ТОЛЬКО задокументированные read-only методы
// (https://dev.max.ru/docs-api):
//   GET /me                          — информация о боте
//   GET /chats/{chatId}              — информация о чате/канале
//   GET /chats/{chatId}/members/me   — членство бота (is_admin, права)
//   GET /messages?chat_id=&count=    — последние посты канала
//   GET /messages/{messageId}        — один пост по mid
//   GET /updates                     — события Long Polling
// Никаких отправок и изменений: тестер только читает.

export const MAX_API_BASE = "https://platform-api2.max.ru";

/** Все типы событий Update по документации. Событий рекламы среди них НЕТ. */
export const DOCUMENTED_UPDATE_TYPES = [
  "bot_added",
  "bot_started",
  "bot_stopped",
  "bot_removed",
  "chat_title_changed",
  "dialog_cleared",
  "dialog_muted",
  "dialog_unmuted",
  "dialog_removed",
  "message_callback",
  "message_created",
  "message_edited",
  "message_removed",
  "comment_created",
  "comment_edited",
  "comment_removed",
  "user_added",
  "user_removed",
  "bot_admin_permissions_changed",
];

export type ApiErrorKind =
  | "auth" // 401 — неверный токен
  | "forbidden" // 403 — нет доступа (бот не админ / приостановлен)
  | "notfound" // 404 — объект не найден или недоступен
  | "method" // 405 — метод/режим недоступен (например, Webhook вместо Long Polling)
  | "server" // 5xx
  | "network" // сеть/TLS
  | "timeout"; // превышен таймаут

export class MaxApiError extends Error {
  kind: ApiErrorKind;
  status: number;
  httpMethod: string;
  path: string;
  body: string;
  constructor(kind: ApiErrorKind, status: number, httpMethod: string, path: string, body: string) {
    // Токен сюда никогда не попадает: path и body его не содержат.
    super(`${httpMethod} ${path} -> ${status} (${kind}): ${body.slice(0, 200)}`);
    this.name = "MaxApiError";
    this.kind = kind;
    this.status = status;
    this.httpMethod = httpMethod;
    this.path = path;
    this.body = body.slice(0, 2000);
  }
}

function kindOf(status: number): ApiErrorKind {
  if (status === 401) return "auth";
  if (status === 403) return "forbidden";
  if (status === 404) return "notfound";
  if (status === 405) return "method";
  if (status >= 500) return "server";
  return "server";
}

export class MaxClient {
  constructor(
    private token: string,
    private base: string = MAX_API_BASE,
    private timeoutMs = 15000,
  ) {}

  private async call(httpMethod: string, path: string): Promise<any> {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    let res: Response;
    try {
      res = await fetch(this.base + path, {
        method: httpMethod,
        headers: { Authorization: this.token },
        signal: ctrl.signal,
      });
    } catch (e) {
      clearTimeout(timer);
      if (e instanceof Error && e.name === "AbortError") {
        throw new MaxApiError("timeout", 0, httpMethod, path, `no response in ${this.timeoutMs} ms`);
      }
      throw new MaxApiError("network", 0, httpMethod, path, e instanceof Error ? e.message : String(e));
    } finally {
      clearTimeout(timer);
    }
    const text = await res.text();
    if (!res.ok) throw new MaxApiError(kindOf(res.status), res.status, httpMethod, path, text);
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      throw new MaxApiError("server", res.status, httpMethod, path, "invalid JSON response");
    }
  }

  /** GET /me — проверка токена + данные бота (без секретов в ответе). */
  me(): Promise<any> {
    return this.call("GET", "/me");
  }

  /** GET /chats/{chatId} — информация о канале. */
  chat(chatId: string): Promise<any> {
    return this.call("GET", `/chats/${encodeURIComponent(chatId)}`);
  }

  /** GET /chats/{chatId}/members/me — членство и права бота. */
  membership(chatId: string): Promise<any> {
    return this.call("GET", `/chats/${encodeURIComponent(chatId)}/members/me`);
  }

  /** GET /messages?chat_id — последние посты канала (бот должен быть администратором). */
  async history(chatId: string, count = 10): Promise<any[]> {
    const data = await this.call(
      "GET",
      `/messages?chat_id=${encodeURIComponent(chatId)}&count=${Math.min(100, Math.max(1, count))}`,
    );
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.messages)) return data.messages;
    return [];
  }

  /** GET /messages/{messageId} — один пост по mid. 404 = нет или недоступен. */
  messageById(mid: string): Promise<any> {
    return this.call("GET", `/messages/${encodeURIComponent(mid)}`);
  }

  /** GET /updates — события Long Polling. marker — строка (int64). */
  async updates(
    marker: string | null,
    timeoutSec: number,
    types: string[],
  ): Promise<{ updates: any[]; marker: string | null }> {
    const q = new URLSearchParams();
    if (marker !== null) q.set("marker", marker);
    q.set("limit", "100");
    q.set("timeout", String(Math.min(90, Math.max(0, timeoutSec))));
    if (types.length) q.set("types", types.join(","));
    const data = await this.call("GET", `/updates?${q.toString()}`);
    return {
      updates: Array.isArray(data?.updates) ? data.updates : [],
      marker: data?.marker === null || data?.marker === undefined ? null : String(data.marker),
    };
  }
}
