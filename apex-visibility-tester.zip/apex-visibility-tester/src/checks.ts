// APEX MAX API VISIBILITY TESTER — read-only диагностика.
// Статусы (разница принципиальна):
//   success     «Успех»             — подтверждено реальным ответом API.
//   unsupported «Не поддерживается» — в официальном API такой возможности НЕТ
//                                     (не ошибка бота, а ограничение платформы).
//   forbidden   «Нет доступа»       — API ответил 401/403/404 (токен, права, доступ).
//   unknown     «Не удалось проверить» — сеть/таймаут/неоднозначный ответ;
//                                     НЕ успех и НЕ провал, нужна повторная проверка.
import { MaxClient, MaxApiError, DOCUMENTED_UPDATE_TYPES } from "./max.js";

export type Status = "success" | "unsupported" | "forbidden" | "unknown";

export interface CheckItem {
  status: Status;
  title: string;
  detail: string;
  data?: unknown;
}

export interface ChannelReport {
  channelId: string;
  channelInfo: CheckItem;
  membership: CheckItem;
  history: CheckItem;
  realtime: CheckItem;
  rsyaIntegration: CheckItem;
  rsyaContent: CheckItem;
  observedFields: CheckItem;
  lastError: string | null;
}

export interface AuthReport extends CheckItem {
  bot?: { user_id: unknown; username: unknown; first_name: unknown };
}

export interface CheckRunResult {
  checkedAt: number;
  auth: AuthReport;
  channels: ChannelReport[];
}

function errText(e: unknown): string {
  if (e instanceof MaxApiError) return `${e.httpMethod} ${e.path} -> ${e.status || "no-http"} (${e.kind}): ${e.body.slice(0, 300)}`;
  if (e instanceof Error) return `${e.name}: ${e.message}`.slice(0, 300);
  return String(e).slice(0, 300);
}

/** Верхнеуровневые ключи объектов — какие поля API реально отдал. */
export function topLevelFields(value: unknown): string[] {
  if (!value || typeof value !== "object" || Array.isArray(value)) return [];
  return Object.keys(value as Record<string, unknown>).sort();
}

async function checkAuth(client: MaxClient): Promise<AuthReport> {
  try {
    const me = await client.me();
    return {
      status: "success",
      title: "Авторизация бота",
      detail: `Токен принят. Бот: ${String(me?.first_name ?? "?")} (@${String(me?.username ?? "?")}, id ${String(me?.user_id ?? "?")}).`,
      bot: { user_id: me?.user_id ?? null, username: me?.username ?? null, first_name: me?.first_name ?? null },
    };
  } catch (e) {
    if (e instanceof MaxApiError && (e.kind === "auth" || e.kind === "forbidden")) {
      return { status: "forbidden", title: "Авторизация бота", detail: `API отклонил токен. ${errText(e)}` };
    }
    return { status: "unknown", title: "Авторизация бота", detail: `Не удалось проверить: ${errText(e)}` };
  }
}

async function checkChannel(client: MaxClient, channelId: string): Promise<ChannelReport> {
  let lastError: string | null = null;
  const remember = (e: unknown): void => {
    if (!lastError) lastError = errText(e);
  };

  // 1) GET /chats/{chatId}
  let channelInfo: CheckItem;
  let chatType: string | null = null;
  try {
    const chat = await client.chat(channelId);
    chatType = typeof chat?.type === "string" ? chat.type : null;
    channelInfo = {
      status: "success",
      title: "Информация о канале",
      detail: `Тип: ${chatType ?? "?"}, название: ${String(chat?.title ?? "?")}, статус: ${String(chat?.status ?? "?")}, участников: ${String(chat?.participants_count ?? "?")}, публичный: ${String(chat?.is_public ?? "?")}.`,
      data: {
        chat_id: chat?.chat_id ?? null,
        type: chat?.type ?? null,
        status: chat?.status ?? null,
        title: chat?.title ?? null,
        participants_count: chat?.participants_count ?? null,
        is_public: chat?.is_public ?? null,
        link: chat?.link ?? null,
        description: typeof chat?.description === "string" ? String(chat.description).slice(0, 200) : null,
        observed_top_fields: topLevelFields(chat),
      },
    };
  } catch (e) {
    remember(e);
    channelInfo =
      e instanceof MaxApiError && (e.kind === "forbidden" || e.kind === "notfound" || e.kind === "auth")
        ? { status: "forbidden", title: "Информация о канале", detail: `Нет доступа. ${errText(e)}` }
        : { status: "unknown", title: "Информация о канале", detail: `Не удалось проверить: ${errText(e)}` };
  }

  // 2) GET /chats/{chatId}/members/me
  let membership: CheckItem;
  try {
    const m = await client.membership(channelId);
    membership = {
      status: "success",
      title: "Права бота",
      detail: `is_admin=${String(m?.is_admin ?? "?")}, is_owner=${String(m?.is_owner ?? "?")}.`,
      data: {
        is_admin: m?.is_admin ?? null,
        is_owner: m?.is_owner ?? null,
        permissions: m?.permissions ?? null,
        observed_top_fields: topLevelFields(m),
      },
    };
  } catch (e) {
    remember(e);
    membership =
      e instanceof MaxApiError && (e.kind === "forbidden" || e.kind === "notfound" || e.kind === "auth")
        ? { status: "forbidden", title: "Права бота", detail: `Нет доступа. ${errText(e)}` }
        : { status: "unknown", title: "Права бота", detail: `Не удалось проверить: ${errText(e)}` };
  }

  // 3) GET /messages?chat_id — история официальным методом
  let history: CheckItem;
  let historyFields: string[] = [];
  let historyCount = 0;
  try {
    const posts = await client.history(channelId, 10);
    historyCount = posts.length;
    const union = new Set<string>();
    for (const p of posts) for (const k of topLevelFields(p)) union.add(k);
    historyFields = [...union].sort();
    history =
      posts.length > 0
        ? {
            status: "success",
            title: "История / последние посты",
            detail: `Официальный метод GET /messages вернул ${posts.length} пост(ов). Это обычные посты канала — сам факт работы метода НЕ доказывает доступность рекламы РСЯ.`,
            data: { count: posts.length, observed_top_fields: historyFields },
          }
        : {
            status: "success",
            title: "История / последние посты",
            detail: "Метод сработал, но вернул пустой список: постов нет либо они недоступны боту.",
            data: { count: 0, observed_top_fields: [] },
          };
  } catch (e) {
    remember(e);
    history =
      e instanceof MaxApiError && (e.kind === "forbidden" || e.kind === "notfound" || e.kind === "auth")
        ? {
            status: "forbidden",
            title: "История / последние посты",
            detail: `История недоступна: обычно это значит, что бот не администратор канала. ${errText(e)}`,
          }
        : { status: "unknown", title: "История / последние посты", detail: `Не удалось проверить: ${errText(e)}` };
  }

  // 4) Реальное время: поток событий достижим? (короткий Long Polling без marker)
  let realtime: CheckItem;
  try {
    const r = await client.updates(null, 5, ["message_created"]);
    realtime = {
      status: "success",
      title: "Новые сообщения в реальном времени",
      detail: `Поток событий GET /updates отвечает (marker ${r.marker === null ? "null" : "получен"}, событий за 5 сек: ${r.updates.length}). Получение КОНКРЕТНЫХ новых постов подтверждается только мониторингом — запустите «Начать мониторинг».`,
      data: { marker: r.marker, sample_updates: r.updates.length },
    };
  } catch (e) {
    remember(e);
    realtime =
      e instanceof MaxApiError && e.kind === "method"
        ? {
            status: "unknown",
            title: "Новые сообщения в реальном времени",
            detail: `Long Polling отклонён (405): вероятно, на боте активна Webhook-подписка — тогда события идут на Webhook, а не в /updates. ${errText(e)}`,
          }
        : e instanceof MaxApiError && (e.kind === "auth" || e.kind === "forbidden")
          ? { status: "forbidden", title: "Новые сообщения в реальном времени", detail: `Нет доступа. ${errText(e)}` }
          : { status: "unknown", title: "Новые сообщения в реальном времени", detail: `Не удалось проверить: ${errText(e)}` };
  }

  // 5–6) РСЯ: в API нет ни метода, ни события, ни поля. Это ограничение платформы.
  const noAdFieldsNote =
    historyFields.length > 0
      ? ` В ${historyCount} полученном(ых) посте(ах) поля верхнего уровня: ${historyFields.join(", ")} — среди них признаков рекламы нет, но это не доказывает отсутствие рекламы.`
      : "";
  const rsyaIntegration: CheckItem = {
    status: "unsupported",
    title: "Посты интеграции Яндекса",
    detail:
      `Официальный API не предоставляет способа получить «посты от интеграции Яндекса»: ` +
      `в Update 19 типов событий (bot_added … bot_admin_permissions_changed) — рекламных среди них нет; ` +
      `объект Message содержит sender/recipient/timestamp/link/body/stat/url — флага источника нет. ` +
      `Проверка возможна только наблюдением: запустите мониторинг и дождитесь реальной публикации.${noAdFieldsNote}`,
  };
  const rsyaContent: CheckItem = {
    status: "unsupported",
    title: "Содержимое рекламных постов РСЯ",
    detail:
      "Содержимое рекламного поста бот увидит только если платформа доставит его как обычное событие message_created " +
      "или вернёт в истории — а факт такой доставки документацией не подтверждён. До первого реально полученного " +
      "подозрительного поста действует вердикт «Источник рекламы не подтверждён».",
  };

  const observedFields: CheckItem = {
    status: historyFields.length > 0 ? "success" : "unknown",
    title: "Доступные поля постов",
    detail:
      historyFields.length > 0
        ? `Реально наблюдаемые поля верхнего уровня: ${historyFields.join(", ")}. Значения и вложения показываются в мониторинге для каждого полученного поста.`
        : "Полей нет: история недоступна, нечего анализировать.",
    data: { fields: historyFields },
  };
  void chatType;

  return { channelId, channelInfo, membership, history, realtime, rsyaIntegration, rsyaContent, observedFields, lastError };
}

export async function runChecks(client: MaxClient, channelIds: string[]): Promise<CheckRunResult> {
  const auth = await checkAuth(client);
  const channels: ChannelReport[] = [];
  if (auth.status === "success") {
    for (const id of channelIds) {
      channels.push(await checkChannel(client, id));
    }
  } else {
    for (const id of channelIds) {
      const blocked: CheckItem = {
        status: "unknown",
        title: "Проверка пропущена",
        detail: "Авторизация не прошла — проверки канала невозможны до исправления токена.",
      };
      channels.push({
        channelId: id,
        channelInfo: blocked,
        membership: blocked,
        history: blocked,
        realtime: blocked,
        rsyaIntegration: blocked,
        rsyaContent: blocked,
        observedFields: blocked,
        lastError: null,
      });
    }
  }
  return { checkedAt: Date.now(), auth, channels };
}

export { DOCUMENTED_UPDATE_TYPES };
