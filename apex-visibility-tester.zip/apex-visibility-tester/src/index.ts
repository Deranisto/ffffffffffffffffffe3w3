// APEX MAX API VISIBILITY TESTER — точка входа.
// Проверки при старте: MAX_BOT_TOKEN и DIAG_KEY обязаны быть заданы,
// иначе процесс завершается с объяснением (fail-fast, без запуска беззащитного сервера).
// Значения секретов в лог не выводятся — только факт наличия.
import fs from "node:fs";
import path from "node:path";
import { MaxClient } from "./max.js";
import { Monitor } from "./monitor.js";
import { createServer } from "./server.js";

const VERSION = "0.1.0";

function log(...a: unknown[]): void {
  console.log(new Date().toISOString(), ...a);
}

function loadDotEnv(): void {
  const p = path.resolve(process.cwd(), ".env");
  if (!fs.existsSync(p)) return;
  for (const line of fs.readFileSync(p, "utf8").split("\n")) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const i = t.indexOf("=");
    if (i < 0) continue;
    const k = t.slice(0, i).trim();
    let v = t.slice(i + 1).trim();
    if (v.length >= 2 && ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'")))) {
      v = v.slice(1, -1);
    }
    if (!(k in process.env)) process.env[k] = v;
  }
}

async function main(): Promise<void> {
  loadDotEnv();
  const token = (process.env.MAX_BOT_TOKEN ?? "").trim();
  const diagKey = (process.env.DIAG_KEY ?? "").trim();
  const port = Number(process.env.PORT ?? "3000");
  const dataPath = (process.env.DATA_PATH ?? "data/monitor.json").trim() || "data/monitor.json";
  const pollTimeout = Math.min(90, Math.max(0, Number(process.env.POLL_TIMEOUT ?? "30") || 30));

  if (!token) {
    console.error("FATAL: не задан MAX_BOT_TOKEN (переменная окружения или .env). Сервер не запущен.");
    process.exit(1);
  }
  if (!diagKey) {
    console.error("FATAL: не задан DIAG_KEY. Без него диагностические маршруты были бы открыты всем — сервер не запущен.");
    process.exit(1);
  }
  if (!Number.isFinite(port) || port < 1 || port > 65535) {
    console.error("FATAL: некорректный PORT.");
    process.exit(1);
  }

  log(`APEX MAX API VISIBILITY TESTER v${VERSION}`);
  log(`config: MAX_BOT_TOKEN present=yes (скрыт), DIAG_KEY present=yes (скрыт), PORT=${port}, DATA_PATH=${dataPath}, POLL_TIMEOUT=${pollTimeout}`);

  const client = new MaxClient(token);
  const monitor = new Monitor(client, dataPath, pollTimeout, (line) => log(`[monitor] ${line}`));

  if (monitor.state.active && monitor.state.channels.length) {
    log(`restore: мониторинг был активен для [${monitor.state.channels.join(", ")}] — продолжаю`);
    monitor.resume();
  } else {
    log("restore: активного мониторинга нет");
  }

  const server = createServer({ client, monitor, diagKey, version: VERSION });
  server.listen(port, () => {
    log(`HTTP: :${port} — панель и API готовы (только чтение, без отправок в каналы)`);
  });

  const shutdown = (): void => {
    log("Остановка...");
    monitor.state.active = false;
    server.close(() => {
      log("Остановлено.");
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

void main().catch((e) => {
  console.error("fatal:", e);
  process.exit(1);
});
