// APEX MAX API VISIBILITY TESTER — мониторинг событий Long Polling.
// Режим наблюдения: фиксирует время начала, копит события с метками,
// раскладывает новые посты по каналам и честно оценивает источник.
//
// Вердикты источника (единственно честные при текущем API):
//   unconfirmed — «НЕВОЗМОЖНО ПОДТВЕРДИТЬ ЧЕРЕЗ ДОСТУПНЫЙ API»
//   possible-ad — «ВОЗМОЖНО РЕКЛАМА — ИСТОЧНИК НЕ ПОДТВЕРЖДЁН»
//                 (текст совпал с необязательной подсказкой-маркером оператора;
//                 совпадение НЕ доказывает, что это РСЯ).
// Мониторинг не видит события до своего запуска: у Long Polling ограниченный
// срок хранения, пропущенное во время простоя восстановить нельзя.
// Состояние пишется в JSON-файл после каждой пачки: рестарт сервера
// продолжает с сохранённого marker; разрыв помечается событием
// monitoring_resumed с честной оговоркой о возможном пропуске.
import fs from "node:fs";
import path from "node:path";
import { MaxClient, MaxApiError } from "./max.js";

export type SourceVerdict = "unconfirmed" | "possible-ad";

export interface StoredEvent {
  ts: number;
  update_type: string;
  chat_id: string;
  note: string;
}

export interface StoredMessage {
  ts: number;
  channelId: string;
  mid: string | null;
  text: string;
  sender: string | null;
  timestamp: number | null;
  verdict: SourceVerdict;
  fields: string[];
  raw: unknown;
}

export interface MonitorState {
  active: boolean;
  channels: string[];
  hint: string;
  since: number | null;
  marker: string | null;
  events: StoredEvent[];
  messages: Record<string, StoredMessage[]>;
  log: string[];
}

const MAX_EVENTS = 300;
const MAX_MESSAGES_PER_CHANNEL = 50;
const MAX_LOG = 200;

function emptyState(): MonitorState {
  return { active: false, channels: [], hint: "", since: null, marker: null, events: [], messages: {}, log: [] };
}

/** Безопасный разбор message_created / message_edited без выдуманных полей. */
export function extractPost(update: unknown): {
  chatId: string;
  text: string;
  sender: string | null;
  mid: string | null;
  timestamp: number | null;
  fields: string[];
} | null {
  if (!update || typeof update !== "object") return null;
  const u = update as Record<string, any>;
  if (u.update_type !== "message_created" && u.update_type !== "message_edited") return null;
  const m = u.message;
  if (!m || typeof m !== "object") return null;
  const chatId = m.chat_id ?? u.chat_id;
  if (chatId === undefined || chatId === null || chatId === "") return null;
  const body = m.body && typeof m.body === "object" ? m.body : {};
  const text = typeof body.text === "string" ? body.text : typeof m.text === "string" ? m.text : "";
  const s = m.sender?.user_id ?? m.sender?.id ?? null;
  const mid = m.mid ?? m.message_id ?? m.id ?? body.mid ?? null;
  const ts = typeof m.timestamp === "number" ? m.timestamp : typeof u.timestamp === "number" ? u.timestamp : null;
  const fields = m && typeof m === "object" ? Object.keys(m).sort() : [];
  return {
    chatId: String(chatId),
    text,
    sender: s === null || s === undefined ? null : String(s),
    mid: mid === null || mid === undefined ? null : String(mid),
    timestamp: ts,
    fields,
  };
}

/** Подсказка оператора — лишь повод присмотреться, не доказательство РСЯ. */
export function verdictFor(text: string, hint: string): SourceVerdict {
  const h = hint.trim().toLowerCase();
  if (h && text.toLowerCase().includes(h)) return "possible-ad";
  return "unconfirmed";
}

function fingerprint(update: unknown): string {
  const s = typeof update === "string" ? update : JSON.stringify(update ?? null);
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return `u${(h >>> 0).toString(16)}_${s.length}`;
}

export class Monitor {
  private running = false;
  private seen = new Set<string>();
  state: MonitorState = emptyState();

  constructor(
    private client: MaxClient,
    private storePath: string,
    private pollTimeoutSec: number,
    private onLog: (line: string) => void = () => {},
  ) {
    this.load();
  }

  private load(): void {
    try {
      if (!fs.existsSync(this.storePath)) return;
      const raw = JSON.parse(fs.readFileSync(this.storePath, "utf8")) as Partial<MonitorState>;
      if (raw && typeof raw === "object") {
        this.state = { ...emptyState(), ...raw };
        if (!Array.isArray(this.state.events)) this.state.events = [];
        if (!this.state.messages || typeof this.state.messages !== "object") this.state.messages = {};
        if (!Array.isArray(this.state.log)) this.state.log = [];
      }
    } catch {
      this.state = emptyState();
    }
  }

  private save(): void {
    try {
      fs.mkdirSync(path.dirname(path.resolve(this.storePath)), { recursive: true });
      fs.writeFileSync(path.resolve(this.storePath), JSON.stringify(this.state));
    } catch (e) {
      this.onLog(`store save failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  }

  pushLog(line: string): void {
    const entry = `${new Date().toISOString()} ${line}`;
    this.state.log.push(entry);
    if (this.state.log.length > MAX_LOG) this.state.log.splice(0, this.state.log.length - MAX_LOG);
    this.onLog(entry);
    this.save();
  }

  start(channels: string[], hint: string): void {
    this.state.active = true;
    this.state.channels = channels;
    this.state.hint = hint.trim().slice(0, 200);
    this.state.since = Date.now();
    for (const c of channels) {
      if (!this.state.messages[c]) this.state.messages[c] = [];
    }
    this.pushLog(`monitoring started: channels=[${channels.join(", ")}]${this.state.hint ? ` hint="${this.state.hint}"` : ""}`);
    this.save();
    this.run();
  }

  stop(): void {
    this.state.active = false;
    this.running = false;
    this.pushLog("monitoring stopped by operator");
    this.save();
  }

  /** Продолжить после рестарта сервера с честной пометкой о разрыве. */
  resume(): void {
    if (!this.state.active) return;
    this.pushLog(
      "monitoring_resumed after server restart: продолжение с сохранённого marker; " +
        "события за время простоя восстановить нельзя (ограничение Long Polling) — отсутствие рекламы в журнале НЕ означает её отсутствие в каналах",
    );
    this.run();
  }

  get running_(): boolean {
    return this.running;
  }

  private run(): void {
    if (this.running) return;
    this.running = true;
    void this.loop();
  }

  private async loop(): Promise<void> {
    let backoff = 3000;
    while (this.running && this.state.active) {
      try {
        const res = await this.client.updates(this.state.marker, this.pollTimeoutSec, [
          "message_created",
          "message_edited",
          "message_removed",
        ]);
        backoff = 3000;
        if (res.updates.length) this.ingest(res.updates);
        if (res.marker !== null) {
          this.state.marker = res.marker;
          this.save();
        }
      } catch (e) {
        const msg = e instanceof MaxApiError ? `${e.httpMethod} ${e.path} -> ${e.status || "no-http"} (${e.kind})` : String(e).slice(0, 200);
        this.pushLog(`poll_error: ${msg}`);
        await new Promise((r) => setTimeout(r, backoff));
        backoff = Math.min(backoff * 2, 60000);
      }
    }
    this.running = false;
  }

  ingest(updates: unknown[]): void {
    let changed = false;
    for (const u of updates) {
      const fp = fingerprint(u);
      if (this.seen.has(fp)) continue;
      this.seen.add(fp);
      const t = (u as Record<string, any>)?.update_type;
      const updateType = typeof t === "string" ? t : "?";
      const rawChat = (u as Record<string, any>)?.chat_id ?? (u as Record<string, any>)?.message?.chat_id ?? "";
      this.state.events.push({ ts: Date.now(), update_type: updateType, chat_id: String(rawChat), note: "" });
      changed = true;

      const post = extractPost(u);
      if (!post) continue;
      if (!this.state.channels.includes(post.chatId)) continue;
      const verdict = verdictFor(post.text, this.state.hint);
      const list = this.state.messages[post.chatId] ?? [];
      list.push({
        ts: Date.now(),
        channelId: post.chatId,
        mid: post.mid,
        text: post.text.slice(0, 4000),
        sender: post.sender,
        timestamp: post.timestamp,
        verdict,
        fields: post.fields,
        raw: u,
      });
      while (list.length > MAX_MESSAGES_PER_CHANNEL) list.shift();
      this.state.messages[post.chatId] = list;
      this.pushLog(
        `message in ${post.chatId}: len=${post.text.length} mid=${post.mid ?? "?"} verdict=${verdict === "possible-ad" ? "ВОЗМОЖНО РЕКЛАМА — ИСТОЧНИК НЕ ПОДТВЕРЖДЁН" : "НЕВОЗМОЖНО ПОДТВЕРДИТЬ ЧЕРЕЗ ДОСТУПНЫЙ API"}`,
      );
    }
    if (this.state.events.length > MAX_EVENTS) this.state.events.splice(0, this.state.events.length - MAX_EVENTS);
    if (changed) this.save();
  }
}
