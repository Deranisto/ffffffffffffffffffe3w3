// APEX MAX API VISIBILITY TESTER — панель (без фреймворков).
// Только вызовы собственного backend (/api/*). Токена здесь нет и быть не может:
// сервер берёт MAX_BOT_TOKEN из своего окружения. Ключ доступа и ID каналов
// живут только в памяти вкладки — localStorage не используется.
"use strict";

const $ = (id) => document.getElementById(id);
const keyInput = $("keyInput");
const chAInput = $("chAInput");
const chBInput = $("chBInput");
const hintInput = $("hintInput");
const checkBtn = $("checkBtn");
const startBtn = $("startBtn");
const stopBtn = $("stopBtn");
const connEl = $("connEl");
const connText = $("connText");
const authEl = $("authEl");
const cardA = $("cardA");
const cardB = $("cardB");
const lastCheckEl = $("lastCheckEl");
const monStateEl = $("monStateEl");
const monSinceEl = $("monSinceEl");
const eventsEl = $("eventsEl");
const msgsEl = $("msgsEl");
const logEl = $("logEl");

let pollTimer = null;

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function log(line, isErr) {
  const time = new Date().toLocaleTimeString("ru-RU");
  const div = document.createElement("div");
  if (isErr) div.className = "err";
  div.textContent = `[${time}] ${line}`;
  if (logEl.textContent === "Журнал пуст.") logEl.textContent = "";
  logEl.prepend(div);
}

function setConn(ok, text) {
  connText.textContent = "Подключение: " + text;
  const dot = connEl.querySelector(".dot");
  dot.className = "dot " + (ok === true ? "dot-green" : ok === false ? "dot-red" : "dot-gray");
}

function channels() {
  return [chAInput.value.trim(), chBInput.value.trim()].filter(Boolean).slice(0, 2);
}

async function api(path, body) {
  const key = keyInput.value;
  if (!key) throw new Error("Введите ключ доступа (DIAG_KEY).");
  const res = await fetch(path, {
    method: body === undefined ? "GET" : "POST",
    headers: { "Content-Type": "application/json", "x-diag-key": key },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { ok: false, error: "bad JSON: " + text.slice(0, 200) }; }
  if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

const STATUS_RU = { success: "Успех", unsupported: "Не поддерживается", forbidden: "Нет доступа", unknown: "Не удалось проверить" };

function badge(status) {
  return `<span class="badge b-${esc(status)}">${esc(STATUS_RU[status] || status)}</span>`;
}

function renderCheck(el, title, item) {
  el.innerHTML = `<div class="check"><div class="t">${badge(item.status)} ${esc(title)}</div><div class="d">${esc(item.detail)}</div></div>`;
}

function renderChannelCard(el, name, report) {
  if (!report) { el.textContent = `${name}: нет данных.`; return; }
  const order = ["channelInfo", "membership", "history", "realtime", "rsyaIntegration", "rsyaContent", "observedFields"];
  const titles = {
    channelInfo: "Информация о канале", membership: "Права бота", history: "История / посты",
    realtime: "Реальное время", rsyaIntegration: "Посты интеграции Яндекса",
    rsyaContent: "Содержимое РСЯ", observedFields: "Поля постов",
  };
  let html = `<h3>${esc(name)} <span class="meta">id ${esc(report.channelId)}</span></h3>`;
  for (const k of order) {
    const it = report[k];
    if (it) html += `<div class="check"><div class="t">${badge(it.status)} ${esc(titles[k])}</div><div class="d">${esc(it.detail)}</div></div>`;
  }
  if (report.lastError) html += `<div class="check"><div class="t err">Последняя ошибка API</div><div class="d">${esc(report.lastError)}</div></div>`;
  el.innerHTML = html;
}

async function doCheck() {
  const chs = channels();
  if (!chs.length) { log("Укажите хотя бы один ID канала.", true); return; }
  checkBtn.disabled = true;
  try {
    const r = await api("/api/check", { channels: chs });
    setConn(true, "OK");
    lastCheckEl.textContent = "последняя проверка: " + new Date(r.checkedAt).toLocaleString("ru-RU");
    authEl.innerHTML = `<div class="check"><div class="t">${badge(r.auth.status)} Авторизация</div><div class="d">${esc(r.auth.detail)}</div></div>`;
    renderChannelCard(cardA, "Канал №1", r.channels[0]);
    renderChannelCard(cardB, "Канал №2", r.channels[1] || null);
    log(`Проверка API завершена: auth=${r.auth.status}` + r.channels.map((c) => ` ch${c.channelId}: history=${c.history.status}`).join(""));
  } catch (e) {
    setConn(false, "ошибка");
    log("Проверка API: " + e.message, true);
  } finally {
    checkBtn.disabled = false;
  }
}

function fmtTs(ts) {
  try { return new Date(ts).toLocaleString("ru-RU"); } catch { return String(ts); }
}

function renderState(st) {
  monStateEl.textContent = "состояние: " + (st.active ? "НАБЛЮДЕНИЕ АКТИВНО" : "остановлен");
  monSinceEl.textContent = "наблюдение с: " + (st.since ? fmtTs(st.since) + ` (каналы: ${(st.channels || []).join(", ")})` : "—");
  if (st.events && st.events.length) {
    eventsEl.innerHTML = st.events.slice().reverse().map((e) =>
      `<div>[${esc(fmtTs(e.ts))}] ${esc(e.update_type)} chat=${esc(e.chat_id)}${e.note ? " " + esc(e.note) : ""}</div>`,
    ).join("");
  } else {
    eventsEl.textContent = st.active
      ? "Ожидание событий… Мониторинг видит только новое, произошедшее после запуска."
      : "Пока нет событий.";
  }
  const groups = st.messages || {};
  const keys = Object.keys(groups);
  if (!keys.length || keys.every((k) => !groups[k].length)) {
    msgsEl.textContent = "Пока нет постов.";
    return;
  }
  msgsEl.innerHTML = keys.map((ch) => {
    const list = groups[ch];
    if (!list.length) return `<div><b>Канал ${esc(ch)}:</b> постов пока нет.</div>`;
    return `<div><b>Канал ${esc(ch)} (${list.length}):</b>` + list.slice().reverse().map((m) => {
      const v = m.verdict === "possible-ad"
        ? `<span class="verdict-possible">ВОЗМОЖНО РЕКЛАМА — ИСТОЧНИК НЕ ПОДТВЕРЖДЁН</span>`
        : `<span class="verdict-unconfirmed">НЕВОЗМОЖНО ПОДТВЕРДИТЬ ЧЕРЕЗ ДОСТУПНЫЙ API</span>`;
      return `<div class="msg"><div>[${esc(fmtTs(m.ts))}] mid=${esc(m.mid ?? "?")} sender=${esc(m.sender ?? "канал/неизвестно")}</div>` +
        `<div>поля: ${esc((m.fields || []).join(", "))}</div>` +
        `<div>${v}</div><div>${esc(m.text.slice(0, 600))}</div></div>`;
    }).join("") + `</div>`;
  }).join("");
}

async function refreshState(silent) {
  try {
    const st = await api("/api/monitor/state");
    renderState(st);
    if (st.active && !pollTimer) startPolling();
    if (!st.active && pollTimer) stopPolling();
    return st;
  } catch (e) {
    if (!silent) log("Состояние мониторинга: " + e.message, true);
    return null;
  }
}

function startPolling() {
  if (pollTimer) return;
  pollTimer = setInterval(() => { refreshState(true); }, 3000);
}

function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

async function doStart() {
  const chs = channels();
  if (!chs.length) { log("Укажите хотя бы один ID канала.", true); return; }
  try {
    const r = await api("/api/monitor/start", { channels: chs, hint: hintInput.value.trim() });
    log(`Мониторинг запущен: ${r.channels.join(", ")}. ${r.note}`);
    startPolling();
    await refreshState(true);
  } catch (e) {
    log("Запуск мониторинга: " + e.message, true);
  }
}

async function doStop() {
  try {
    await api("/api/monitor/stop", {});
    log("Мониторинг остановлен.");
    stopPolling();
    await refreshState(true);
  } catch (e) {
    log("Остановка мониторинга: " + e.message, true);
  }
}

async function boot() {
  try {
    const h = await fetch("/api/health").then((r) => r.json());
    setConn(true, `сервер v${h.version || "?"}, мониторинг: ${h.monitorActive ? "активен" : "неактивен"}`);
    if (h.monitorActive) startPolling();
  } catch {
    setConn(false, "сервер недоступен");
  }
  checkBtn.addEventListener("click", doCheck);
  startBtn.addEventListener("click", doStart);
  stopBtn.addEventListener("click", doStop);
}

document.addEventListener("DOMContentLoaded", boot);
